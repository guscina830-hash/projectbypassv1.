package com.oneproject.projectbypass

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.graphics.Typeface
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.widget.*
import java.net.HttpURLConnection
import java.net.URL
import kotlin.concurrent.thread

class MainActivity : Activity() {
    private val bg = Color.rgb(18, 10, 13)
    private val panel = Color.rgb(43, 18, 25)
    private val red = Color.rgb(218, 35, 61)
    private val white = Color.WHITE
    private val muted = Color.rgb(220, 175, 184)

    // Demo/local gate only. Credentials inside an APK can be extracted.
    private val validUsername = "ONE PROJECT"
    private val validPassword = "PROJECT BYPASS V1.0"

    private lateinit var root: LinearLayout
    private lateinit var resultText: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        showLogin()
    }

    private fun baseLayout(): LinearLayout {
        return LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(dp(24), dp(28), dp(24), dp(24))
            setBackgroundColor(bg)
        }
    }

    private fun heading(subtitle: String): View {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
        }
        val title = TextView(this).apply {
            text = "PROJECT BYPASS"
            textSize = 25f
            setTextColor(red)
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
        }
        val version = TextView(this).apply {
            text = "V1.0  •  $subtitle"
            textSize = 12f
            setTextColor(muted)
            gravity = Gravity.CENTER
            setPadding(0, dp(6), 0, dp(24))
        }
        box.addView(title)
        box.addView(version)
        return box
    }

    private fun label(text: String): TextView = TextView(this).apply {
        this.text = text
        textSize = 13f
        typeface = Typeface.DEFAULT_BOLD
        setTextColor(muted)
        setPadding(0, dp(12), 0, dp(6))
    }

    private fun edit(hintText: String, password: Boolean = false): EditText {
        return EditText(this).apply {
            hint = hintText
            textSize = 15f
            setTextColor(white)
            setHintTextColor(Color.rgb(160, 130, 137))
            setSingleLine(true)
            setPadding(dp(14), dp(12), dp(14), dp(12))
            setBackgroundColor(panel)
            if (password) inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
        }
    }

    private fun actionButton(text: String): Button = Button(this).apply {
        this.text = text
        isAllCaps = false
        textSize = 15f
        setTextColor(white)
        setBackgroundTintList(android.content.res.ColorStateList.valueOf(red))
    }

    private fun showLogin() {
        root = baseLayout()
        root.addView(heading("SECURE ACCESS"))
        root.addView(label("USERNAME"))
        val username = edit("Enter username")
        root.addView(username, matchWrap())
        root.addView(label("PASSWORD"))
        val password = edit("Enter password", true)
        root.addView(password, matchWrap())

        val show = CheckBox(this).apply {
            text = "Show password"
            textSize = 13f
            setTextColor(muted)
            buttonTintList = android.content.res.ColorStateList.valueOf(red)
            setOnCheckedChangeListener { _, checked ->
                val cursor = password.selectionStart.coerceAtLeast(0)
                password.inputType = InputType.TYPE_CLASS_TEXT or
                    if (checked) InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD
                    else InputType.TYPE_TEXT_VARIATION_PASSWORD
                password.setSelection(cursor.coerceAtMost(password.text.length))
            }
        }
        root.addView(show)
        val login = actionButton("LOGIN")
        val loginParams = matchWrap().apply { topMargin = dp(18) }
        root.addView(login, loginParams)
        login.setOnClickListener {
            if (username.text.toString() == validUsername && password.text.toString() == validPassword) {
                showHome()
            } else {
                Toast.makeText(this, "Username atau password salah", Toast.LENGTH_SHORT).show()
            }
        }
        val note = TextView(this).apply {
            text = "PROJECT BYPASS V1.0"
            textSize = 11f
            setTextColor(muted)
            gravity = Gravity.CENTER
            setPadding(0, dp(24), 0, 0)
        }
        root.addView(note)
        setContentView(root)
    }

    private fun showHome() {
        root = baseLayout()
        root.addView(heading("LINK PROCESSOR"))
        root.addView(label("PASTE LINK"))
        val linkInput = edit("https://example.com/your-link")
        linkInput.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_URI
        root.addView(linkInput, matchWrap())

        val process = actionButton("PROCESS LINK")
        root.addView(process, matchWrap().apply { topMargin = dp(16) })
        root.addView(label("FINAL URL / RESULT"))
        resultText = TextView(this).apply {
            text = "Hasil akan muncul di sini."
            textSize = 14f
            setTextColor(white)
            setPadding(dp(14), dp(14), dp(14), dp(14))
            setBackgroundColor(panel)
            minHeight = dp(72)
        }
        root.addView(resultText, matchWrap())

        val copy = actionButton("COPY LINK")
        root.addView(copy, matchWrap().apply { topMargin = dp(12) })
        copy.setOnClickListener {
            val value = resultText.text.toString()
            if (value.startsWith("http://") || value.startsWith("https://")) {
                val clipboard = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                clipboard.setPrimaryClip(ClipData.newPlainText("Final URL", value))
                Toast.makeText(this, "Link disalin", Toast.LENGTH_SHORT).show()
            } else {
                Toast.makeText(this, "Belum ada link untuk disalin", Toast.LENGTH_SHORT).show()
            }
        }

        process.setOnClickListener {
            val raw = linkInput.text.toString().trim()
            val parsed = runCatching { URL(raw) }.getOrNull()
            if (parsed == null || (parsed.protocol != "http" && parsed.protocol != "https")) {
                Toast.makeText(this, "Masukkan URL http/https yang valid", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            process.isEnabled = false
            resultText.text = "Memproses redirect HTTP..."
            thread {
                val outcome = resolveHttpRedirects(raw)
                runOnUiThread {
                    process.isEnabled = true
                    resultText.text = outcome
                }
            }
        }

        val info = TextView(this).apply {
            text = "Info: aplikasi hanya mengikuti redirect HTTP publik. CAPTCHA, login, verifikasi, dan kewajiban subscribe tidak dilewati. Beberapa situs memakai JavaScript atau proteksi sehingga tidak bisa diproses di sini."
            textSize = 11f
            setTextColor(muted)
            setPadding(0, dp(18), 0, 0)
        }
        root.addView(info)
        setContentView(root)
    }

    private fun resolveHttpRedirects(start: String): String {
        var current = start
        return try {
            repeat(8) {
                val connection = (URL(current).openConnection() as HttpURLConnection).apply {
                    instanceFollowRedirects = false
                    requestMethod = "GET"
                    connectTimeout = 10000
                    readTimeout = 10000
                    setRequestProperty("User-Agent", "ProjectBypass/1.0")
                }
                val code = connection.responseCode
                val location = connection.getHeaderField("Location")
                connection.disconnect()
                if (code in 300..399 && !location.isNullOrBlank()) {
                    current = URL(URL(current), location).toString()
                } else {
                    return current
                }
            }
            "Batas redirect tercapai. URL terakhir:\\n$current"
        } catch (e: Exception) {
            "Tidak dapat memproses link ini: ${e.message ?: "kesalahan jaringan"}\\n\\nURL yang dimasukkan:\\n$start"
        }
    }

    private fun matchWrap() = LinearLayout.LayoutParams(
        LinearLayout.LayoutParams.MATCH_PARENT,
        LinearLayout.LayoutParams.WRAP_CONTENT
    )

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()
}
